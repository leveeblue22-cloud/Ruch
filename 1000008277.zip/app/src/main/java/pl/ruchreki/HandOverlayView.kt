package pl.ruchreki

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.min

/** Rysuje szkielet dłoni nad podglądem z kamery. */
class HandOverlayView(context: Context) : View(context) {
    @Volatile private var hands: List<List<NormalizedLandmark>> = emptyList()
    @Volatile var imgW = 1
    @Volatile var imgH = 1

    private val line = Paint().apply { color = Color.WHITE; strokeWidth = 5f; isAntiAlias = true }
    private val dot = Paint().apply { color = Color.rgb(94, 225, 255); isAntiAlias = true }

    private val conn = listOf(
        0 to 1, 1 to 2, 2 to 3, 3 to 4, 0 to 5, 5 to 6, 6 to 7, 7 to 8, 5 to 9, 9 to 10, 10 to 11, 11 to 12,
        9 to 13, 13 to 14, 14 to 15, 15 to 16, 13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
    )

    fun update(h: List<List<NormalizedLandmark>>) {
        hands = h
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = imgW.toFloat()
        val h = imgH.toFloat()
        val s = min(width / w, height / h)
        val ox = (width - w * s) / 2f
        val oy = (height - h * s) / 2f
        for (hand in hands) {
            for ((a, b) in conn) {
                canvas.drawLine(
                    ox + hand[a].x() * w * s, oy + hand[a].y() * h * s,
                    ox + hand[b].x() * w * s, oy + hand[b].y() * h * s, line
                )
            }
            for (p in hand) canvas.drawCircle(ox + p.x() * w * s, oy + p.y() * h * s, 8f, dot)
        }
    }
}
