package pl.ruchreki

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.Executors

/** Etap 1: podgląd z kamery + rozpoznawanie dwóch dłoni (MediaPipe). */
class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: HandOverlayView
    private lateinit var status: TextView
    private var landmarker: HandLandmarker? = null
    private var mirror = true
    private val exec = Executors.newSingleThreadExecutor()

    private val askCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startAll() else status.text = "Brak zgody na kamerę"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = HandOverlayView(this)
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0x88000000.toInt())
            text = "Uruchamianie…"
        }
        val full = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        root.addView(preview, full)
        root.addView(overlay, full)
        root.addView(status, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startAll()
        else askCamera.launch(Manifest.permission.CAMERA)
    }

    private fun startAll() {
        try {
            setupLandmarker()
        } catch (e: Exception) {
            status.text = "Błąd modelu: ${e.message}"
            return
        }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val front = provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
            mirror = front
            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
                .also { it.setAnalyzer(exec) { img -> analyze(img) } }
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, prev, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupLandmarker() {
        val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, _ -> onResult(result) }
            .setErrorListener { e -> runOnUiThread { status.text = "Błąd: ${e.message}" } }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, opts)
    }

    private fun analyze(img: ImageProxy) {
        try {
            val lm = landmarker ?: return
            val bmp = Bitmap.createBitmap(img.width, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(img.planes[0].buffer)
            val m = Matrix().apply {
                postRotate(img.imageInfo.rotationDegrees.toFloat())
                if (mirror) postScale(-1f, 1f, img.width / 2f, img.height / 2f)
            }
            val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            overlay.imgW = rot.width
            overlay.imgH = rot.height
            lm.detectAsync(BitmapImageBuilder(rot).build(), SystemClock.uptimeMillis())
        } finally {
            img.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult) {
        overlay.update(r.landmarks())
        runOnUiThread { status.text = "Dłonie w kadrze: ${r.landmarks().size}" }
    }

    override fun onDestroy() {
        super.onDestroy()
        landmarker?.close()
        exec.shutdown()
    }
}
